@echo off
setlocal
cd /d "%~dp0"
set "FIRMQUILL_DB=%~dp0DEMO-DATA\Harborline-demo.sqlite"
set "FIRMQUILL_MAIN_ORIGIN="
set "FIRMQUILL_WORKER_ORIGIN="
set "FIRMQUILL_MAIN_PORT=4279"
set "FIRMQUILL_WORKER_PORT=4280"
set "FIRMQUILL_TIMEZONE=America/Los_Angeles"
if not exist "%FIRMQUILL_DB%" (
  echo Demo database is missing. Extract the entire ZIP, then run this launcher.
  pause
  exit /b 1
)
if not exist "%~dp0FirmQuill-App\host.mjs" (
  echo App files are missing. Extract the entire ZIP, then run this launcher.
  pause
  exit /b 1
)
where node.exe >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 24.22.3, add it to PATH, and reopen this launcher.
  pause
  exit /b 1
)
echo Local demo only. Owner at http://127.0.0.1:4279/ and worker at http://127.0.0.1:4280/
echo See START-HERE.md for the fictional demo credentials and walkthrough.
node "%~dp0FirmQuill-App\host.mjs" serve
pause
