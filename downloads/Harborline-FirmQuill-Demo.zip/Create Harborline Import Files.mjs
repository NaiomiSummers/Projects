import {readFile,writeFile,mkdtemp,rm,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {openStore,readBooks} from './FirmQuill-App/store.mjs';
import {backupDatabase} from './FirmQuill-App/recovery.mjs';
import {exportLite} from './FirmQuill-App/transfer.mjs';

async function main(){
  const source=fileURLToPath(new URL('DEMO-DATA/Harborline-demo.sqlite',import.meta.url));
  const data=await readFile(source);
  if(createHash('sha256').update(data).digest('hex')!=='f31b994765cf0624fb7f2e0cac3ae160b7daf584dc1686f88a57b322ef078d23')
    throw Error('This works only on the unchanged fictional demo database. Extract a clean copy of the ZIP and run this before opening the demo.');
  const temp=await mkdtemp(join(tmpdir(),'harborline-export-'));
  const out=fileURLToPath(new URL('IMPORT-FILES/',import.meta.url));
  const password='HarborlineDemo2026!';
  try{
    await mkdir(out);
    const snapshot=join(temp,'sample.sqlite');
    await writeFile(snapshot,data,{flag:'wx',mode:0o600});
    const db=openStore(snapshot);
    let books;
    try{books=readBooks(db).state;}finally{db.close();}
    await backupDatabase(snapshot,join(out,'Harborline-Full-Suite-Demo.fqdb'),password);
    const snapshotFile=await exportLite(books,password);
    await writeFile(join(out,'Harborline-Demo-Books.firmquill'),snapshotFile.envelope,{flag:'wx'});
    console.log('Created both fictional import files in IMPORT-FILES. See START-HERE.md.');
  }finally{await rm(temp,{recursive:true,force:true});}
}
main().catch(error=>{console.error(error.code==='EEXIST'?'IMPORT-FILES already exists. The existing files were not overwritten. Use another freshly extracted copy.':error.message);process.exitCode=1;});
