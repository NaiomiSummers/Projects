# Harborline Transport Group | FirmQuill Full Suite operations demo

**100% fictional.** These are invented companies, staff, activity, contracts, statements, benefits and paystubs. The references to Amazon are illustrative freight and DSP scenarios. There is no actual Amazon contract, affiliation, endorsement or data. Do not use this database for real employee records, accounting, tax filings, payroll or deposits.

## Start here (Windows)

1. Install Node.js 24.22.3 or a compatible Node 24 runtime, with node.exe on PATH.
2. Extract the entire ZIP to a new writable folder. Keep DEMO-DATA and FirmQuill-App together. Do not copy the sample database over an existing database.
3. Double-click **Start Harborline Demo.cmd**. Leave the window open. It starts the ERP and employee portals on your own computer only, on separate demo ports. This does not run on the Projects website.
4. Open **http://127.0.0.1:4279/** for the ERP or **http://127.0.0.1:4280/** for the employee portal. Sign in with a demo account below. Each demo account must review and accept the current Terms of Service on first use. Declining leaves the records locked.
5. Press Ctrl+C in the host window to stop. To reset, re-extract the ZIP into a new folder. The sample password is public: do not expose this demo to the internet or reuse its password anywhere.

All sample logins use the public password **HarborlineDemo2026!**

| Portal | Username | What to try |
| --- | --- | --- |
| ERP | demo-owner | All five companies, financial reports, group eliminations, active and former staff, asset and stock activity, approvals |
| ERP | demo-hr | Employee records, benefit choices and assigned special-enrollment requests |
| ERP | demo-payroll | Fictional published paystubs and retirement handoff or deduction instructions |
| Employee | demo-corporate | Corporate staff profile and self-service |
| Employee | demo-freight | Freight worker time, sample paystubs, reviews and contacts |
| Employee | demo-parcel | Parcel driver portal, paystubs, time, benefit elections and requests |
| Employee | demo-coach | Shuttle worker profile and assigned job |
| Employee | demo-fleet | Fleet shop employee profile, project and time history |

The books, employees and sample records are in DEMO-DATA/Harborline-demo.sqlite. OPERATIONS-INDEX.jsonl is a plain-text index with one JSON record per shipment, route or maintenance job. Open it in a text editor to search an operation ID, company, vehicle, employee, work date or agreement. Each entry contains the FirmQuill record numbers for the stages reached. The full transactions are in the SQLite file, not just in the index. The matching application (FirmQuill Full Suite 0.2.0 preview, source revision 7449e13313b7f7e68bade0ec23450de94b81b917) is bundled with its license and notices. The demo launcher and data are additions. An experienced operator can use that database file with the matching app by setting FIRMQUILL_DB to its absolute path. The launcher supplies loopback origins, private ports and the America/Los_Angeles clock timezone.

## Import files instead of launching the demo

Run **Create Harborline Import Files.cmd** from a clean extraction before first opening the demo. It creates two files in IMPORT-FILES without editing the bundled database. Both use the sample password above.

- **Harborline-Demo-Books.firmquill**: in an empty Full Suite workspace, use **Portable transfers → Preview Lite backup**, then confirm the import. It includes the five companies’ books, transactions, reporting group, and accounting references, but not worker logins, raw time punches, paystubs, reviews or benefits. It does not merge into existing books.
- **Harborline-Full-Suite-Demo.fqdb**: use the Full Suite recovery utility to restore the entire fictional installation, including the employee portal records and demo logins. From the bundled FirmQuill-App folder run the following with your own absolute paths. Choose a fresh SQLite path outside the program folder. Point a separate local Full Suite host at the restored file with FIRMQUILL_DB; never replace your usual database with this sample.

    node recovery.mjs restore "C:\\path\\IMPORT-FILES\\Harborline-Full-Suite-Demo.fqdb" "C:\\path\\Harborline-Restored.sqlite"

These are native FirmQuill formats, not QuickBooks or Wave company-file importers.

## The fictional ownership structure

Harborline Transport Holdings is the parent and provides executive leadership, accounting, HR, payroll, IT and compliance. It owns four operating companies in this demonstration:

- **Harborline Freight Services:** tractor-trailer linehaul from distribution centers, including a fictional Amazon lane, plus regional customer freight.
- **Harborline Parcel Delivery:** an illustrative Amazon DSP-style last-mile operation with van drivers, dispatchers and route leads.
- **Harborline Workforce Shuttle:** contracts with employers to move staff to work sites and designated pickup points.
- **Harborline Fleet Works:** mechanics, parts and preventive service mainly for the sister fleets, with occasional outside contracts.

The ownership structure is the demo scenario. The app represents the five books together through a reporting group; it does not implement a formal legal ownership register.

## A ten-minute tour

1. Sign into the ERP as demo-owner. Switch companies from the header. Open **Sales**, **Purchasing** and **Reports**. Set report dates manually, for example January 1 through November 26, 2026, or use an earlier year. Each company has dated sample records from January 2020 to November 2026.
2. Under **Reports**, open group reporting for **Harborline Transport Group (fictional)**. Select July 1 to November 26, 2026 to see paired fleet and parent service eliminations. Earlier internal jobs are shown as settled cash entries with the same MNT work order ID in the shop and buyer companies. FirmQuill does not automatically eliminate those older manual entries from gross revenue and expense, although each pair offsets in group net income. Recent unpaid jobs use the native paired intercompany workflow.
3. Switch to **Harborline Fleet Works**. Open **Warehouse**, **Fixed assets**, and **Purchasing**. Look for the maintenance parts kit, stock issues, receipts, bills and the shop equipment depreciation history. In other companies look for active quotes, partly paid invoices and open vendor bills. Each company has a first-month bank reconciliation example.
4. In **Employee records**, compare a current worker and a former worker. Inspect hire and status changes, promotions, training, reporting lines, project assignments and published reviews. In **Approvals**, find a fictional worker shift awaiting review.
5. Open the separate employee portal as demo-parcel. Use **Time**, **Pay**, **Reviews**, **Contacts** and **Benefits**. Download a clearly marked sample PDF paystub. The parcel login shows the operating company’s custom logo and name. Sign in as demo-coach to see the parent’s logo and name instead. Owners can change either mode under **Employee records → Worker portal branding**. The parallel sample enrollment windows run November 15 through December 15, 2026. If visiting after the deadline, demo-owner can open **Benefits administration** and update the example windows and plan dates for a new walkthrough. The preloaded special-enrollment cases and retirement requests remain available for HR review.
6. The 2026 worksheet and fictional PDF paystubs illustrate workflows. This preview does not calculate complete payroll, file tax returns, send deposits or enroll anyone with a real carrier.

## Trace individual operations

| Prefix | Where to go | Unit of work |
| --- | --- | --- |
| FRT | Harborline Freight Services → Sales or History | One load, with a lane, tractor and pallet count |
| DSP | Harborline Parcel Delivery → Sales or History | One dispatched delivery route, with a van and stop count |
| BUS | Harborline Workforce Shuttle → Sales or History | One workforce shuttle run, with a coach and rider count |
| MNT | Harborline Fleet Works → History, Warehouse or Sales | One repair or maintenance work order; recurring jobs show the agreement ID and one-off jobs are billed separately |

Use **History** and browser Find (Ctrl+F) to look up IDs such as DSP-2026-11-01 or MNT-2026-11-01. Select a record number to open it, or use the record numbers in the index. In late November you can follow a paid operation, a partially paid invoice, an unpaid invoice, a completed but unbilled operation, a scheduled order and an open proposal. There are earlier sales credits and prior-month balance settlements as well. In Fleet Works, sample agreement attachments are named FLEET-LINEHAUL, FLEET-VANS and FLEET-COACH. The shared Jobs & time screen groups the individual activities by operational lane, route or service program.

Each operating unit has its own transaction trail. Normal recurring overhead, depreciation and sample payroll cash batches retain their natural billing or payment cadence. The numbers model a fictional test scenario and are not actual carrier volume, contract rates, or payroll.
