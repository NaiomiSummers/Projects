# Harborline Transport Group | FirmQuill Full Suite demo

**100% fictional.** These are invented companies, staff, activity, contracts, statements, benefits and paystubs. The references to Amazon are illustrative freight and DSP scenarios. There is no actual Amazon contract, affiliation, endorsement or data. Do not use this database for real employee records, accounting, tax filings, payroll or deposits.

## Start here (Windows)

1. Install Node.js 24.22.3 or a compatible Node 24 runtime, with node.exe on PATH.
2. Extract the entire ZIP to a new writable folder. Keep DEMO-DATA and FirmQuill-App together. Do not copy the sample database over an existing database.
3. Double-click **Start Harborline Demo.cmd**. Leave the window open. It starts the ERP and employee portals on your own computer only, on separate demo ports. This does not run on the Projects website.
4. Open **http://127.0.0.1:4279/** for the ERP or **http://127.0.0.1:4280/** for the employee portal. Sign in with a demo account below. If the app asks, review and accept its actual terms before entering.
5. Press Ctrl+C in the host window to stop. To reset, re-extract the ZIP into a new folder. The sample password is public: do not expose this demo to the internet or reuse its password anywhere.

All sample logins use the public password **HarborlineDemo2026!**

| Portal | Username | What to try |
| --- | --- | --- |
| ERP | demo-owner | All five companies, financial reports, group eliminations, active and former staff, asset and stock activity, approvals |
| ERP | demo-hr | Employee records, benefit choices and assigned special-enrollment requests |
| ERP | demo-payroll | Fictional published paystubs and retirement handoff or deduction instructions |
| Employee | demo-corporate | Corporate staff profile and self-service |
| Employee | demo-freight | Freight worker time, sample paystubs, reviews and contacts |
| Employee | demo-parcel | Parcel driver portal, paystubs, time, benefit elections and requests |
| Employee | demo-coach | Shuttle worker profile and assigned job |
| Employee | demo-fleet | Fleet shop employee profile, project and time history |

The books, employees and sample records are in DEMO-DATA/Harborline-demo.sqlite. The matching application (FirmQuill Full Suite 0.2.0 preview, source revision f62386b0874955255362ecb396f94edf42b176ce) is bundled with its license and notices. The demo launcher and data are additions. An experienced operator can use that database file with the matching app by setting FIRMQUILL_DB to its absolute path. The launcher supplies loopback origins, private ports and the America/Los_Angeles clock timezone.

## The fictional ownership structure

Harborline Transport Holdings is the parent and provides executive leadership, accounting, HR, payroll, IT and compliance. It owns four operating companies in this demonstration:

- **Harborline Freight Services:** tractor-trailer linehaul from distribution centers, including a fictional Amazon lane, plus regional customer freight.
- **Harborline Parcel Delivery:** an illustrative Amazon DSP-style last-mile operation with van drivers, dispatchers and route leads.
- **Harborline Workforce Shuttle:** contracts with employers to move staff to work sites and designated pickup points.
- **Harborline Fleet Works:** mechanics, parts and preventive service mainly for the sister fleets, with occasional outside contracts.

The ownership structure is the demo scenario. The app represents the five books together through a reporting group; it does not implement a formal legal ownership register.

## A ten-minute tour

1. Sign into the ERP as demo-owner. Switch companies from the header. Open **Sales**, **Purchasing** and **Reports**. Set report dates manually, for example January 1 through November 26, 2026, or use an earlier year. Each company has dated sample records from January 2020 to November 2026.
2. Under **Reports**, open group reporting for **Harborline Transport Group (fictional)**. Select July 1 to November 26, 2026 to see paired fleet and parent service eliminations. Before July 2026 the sample uses paired-in-narrative historical cash journals keyed by matching HIST labels. Full Suite does not automatically eliminate those legacy journals from gross revenue and expense. They offset in group net income. Recent unpaid charges use the native paired intercompany workflow.
3. Switch to **Harborline Fleet Works**. Open **Warehouse**, **Fixed assets**, and **Purchasing**. Look for the maintenance parts kit, stock issues, receipts, bills and the shop equipment depreciation history. In other companies look for active quotes, partly paid invoices and open vendor bills. Each company has a first-month bank reconciliation example.
4. In **Employee records**, compare a current worker and a former worker. Inspect hire and status changes, promotions, training, reporting lines, project assignments and published reviews. In **Approvals**, find a fictional worker shift awaiting review.
5. Open the separate employee portal as demo-parcel. Use **Time**, **Pay**, **Reviews**, **Contacts** and **Benefits**. Download a clearly marked sample PDF paystub. The parcel login shows the operating company’s custom logo and name. Sign in as demo-coach to see the parent’s logo and name instead. Owners can change either mode under **Employee records → Worker portal branding**. The parallel sample enrollment windows run November 15 through December 15, 2026. If visiting after the deadline, demo-owner can open **Benefits administration** and update the example windows and plan dates for a new walkthrough. The preloaded special-enrollment cases and retirement requests remain available for HR review.
6. The 2026 worksheet and fictional PDF paystubs illustrate workflows. This preview does not calculate complete payroll, file tax returns, send deposits or enroll anyone with a real carrier.

All amounts and names are illustrative. Some business records represent monthly summaries rather than a complete per-delivery transaction log.
