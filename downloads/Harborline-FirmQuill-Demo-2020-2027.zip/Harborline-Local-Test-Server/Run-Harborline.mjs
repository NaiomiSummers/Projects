// Local-first bootstrap for this exact fictional Harborline fixture. Not part of the product.
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {lstat,realpath} from 'node:fs/promises';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {dirname,join,resolve} from 'node:path';
import {Writable} from 'node:stream';
import {createInterface} from 'node:readline';
import {spawn} from 'node:child_process';
import {once} from 'node:events';

const root=dirname(fileURLToPath(import.meta.url)), dbMark='!pending-invite:harborline-local-demo';
const users=['demo-coach','demo-corporate','demo-fleet','demo-freight','demo-hr','demo-owner','demo-parcel','demo-payroll'];
const companies=['Harborline Fleet Works','Harborline Freight Services','Harborline Parcel Delivery','Harborline Transport Holdings','Harborline Workforce Shuttle'];
async function verifiedFixture(file){
 const l=await lstat(file);assert(l.isFile()&&!l.isSymbolicLink(),'The fictional database must be a regular local file.');
 const d=new DatabaseSync(file,{readOnly:true});
 try{
  const s=JSON.parse(d.prepare('SELECT body FROM books WHERE id=1').get().body);
  assert.deepEqual(s.companies.map(c=>c.name).sort(),companies,'Not the designated fictional Harborline fixture.');
  assert(s.companies.every(c=>c.reconciliations.length>=97&&c.reconciliations.some(r=>r.date==='2027-12-31')),'Not the designated extended fictional Harborline fixture.');
  const a=d.prepare("SELECT username,hash FROM accounts WHERE username LIKE 'demo-%' ORDER BY username").all();
  assert.deepEqual(a.map(r=>r.username),users,'This launcher only configures the eight designated demo accounts.');
  const remaining=a.filter(r=>r.hash===dbMark).length;
  assert(remaining===0||remaining===users.length,'First-use setup is inconsistent. Restore a fresh demo copy instead of modifying accounts.');
  return remaining>0;
 }finally{d.close();}
}
export async function configureDemo(file,app,password){
 assert(typeof password==='string'&&password.length>=14&&password.length<=128&&password.trim()===password,'Use a 14–128 character local demo password with no leading or trailing spaces.');
 assert(!['HarborlineDemo2026!','passwordpassword'].includes(password),'Use a new password, not a previous demo default.');
 assert(await verifiedFixture(file),'This demo already has credentials. Setup never resets them.');
 const {openStore,tx,passwordHash}=await import(pathToFileURL(join(resolve(app),'store.mjs')));
 const hashes=await Promise.all(users.map(()=>passwordHash(password)));
 const d=openStore(file);
 try{tx(d,()=>{
  const write=d.prepare('UPDATE accounts SET hash=?,authVersion=authVersion+1 WHERE username=? AND hash=?');
  for(const [i,user] of users.entries())assert.equal(write.run(hashes[i],user,dbMark).changes,1,'Setup was already completed for this demo.');
 });}finally{d.close();}
}
async function secret(label){
 assert(process.stdin.isTTY&&process.stdout.isTTY,'Open the supplied launcher in an interactive terminal for first-use credentials.');
 process.stdout.write(label);
 const muted=new Writable({write(c,e,next){next();}});
 const r=createInterface({input:process.stdin,output:muted,terminal:true,historySize:0});
 try{
  return await new Promise((done,no)=>{
   r.once('close',()=>no(Error('Setup cancelled.')));
   r.once('SIGINT',()=>no(Error('Setup cancelled.')));
   r.question('',done);
  });
 }finally{r.close();muted.end();process.stdout.write('\n');}
}
async function main(){
 assert(process.argv.length===2,'Run without arguments.');
 assert(Number(process.versions.node.split('.')[0])===24,'Install Node.js 24 (the fixture was tested on 24.22.3).');
 const file=join(root,'DEMO-DATA','Harborline-2020-2027.sqlite'),app=join(root,'FirmQuill-App'),name=join(app,'host.mjs');
 assert.equal(await realpath(file),file,'Keep the demo database in this local extraction, not in a symbolic link.');
 console.log('Fictional Harborline · local test only');
 if(await verifiedFixture(file)){
   console.log('Create a dedicated password. It initially applies to the eight sandbox logins listed in START-HERE; do not reuse it anywhere else.');
   let p=await secret('New local demo password: '),again=await secret('Confirm: ');
   try{assert.equal(p,again,'Passwords did not match. Restart the launcher to try again.');await configureDemo(file,app,p);}
   finally{p='';again='';}
   console.log('Demo credentials saved. Sign in and review Terms separately for each account.');
 }
 const env={...process.env,TZ:'America/Los_Angeles'};
 for(const k of Object.keys(env))if(k.toUpperCase().startsWith('FIRMQUILL_')||['NODE_OPTIONS','NODE_PATH'].includes(k.toUpperCase()))delete env[k];
 Object.assign(env,{FIRMQUILL_DB:file,FIRMQUILL_MAIN_PORT:'4279',FIRMQUILL_WORKER_PORT:'4280'});
 const child=spawn(process.execPath,[name,'start'],{cwd:app,env,stdio:'inherit',windowsHide:false});
 const stop=()=>{if(process.platform!=='win32')child.kill('SIGINT');};
 process.on('SIGINT',stop);process.on('SIGTERM',stop);
 try{const [code]=await once(child,'exit');process.exitCode=code??0;}
 finally{process.off('SIGINT',stop);process.off('SIGTERM',stop);}
}
if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url)main().catch(e=>{console.error(e.message);process.exitCode=1;});
