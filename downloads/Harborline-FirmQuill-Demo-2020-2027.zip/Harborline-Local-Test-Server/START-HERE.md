# Harborline Transport Group | FirmQuill Full Suite 0.6.5
**Everything in the sample is fictional.** Dates after November 27, 2026
(including all 2027 records) are fictional forward scenarios, not predictions,
current transactions, or tax guidance. Harborline is not a real business or
an Amazon partner. Do not use this copy for real staff, payroll, taxes,
banking, filing or company books.

## Open on Windows
1. Install Node.js 24 and verify with `node --version`. Extract the ZIP into
   a **new writable local folder**. Don't open it from within the ZIP,
   extract over real books, or start it from a synced/network folder.
2. Double-click **Start Harborline Demo.cmd**. On first use, choose and confirm
   a distinct local demo password (14–128 characters). It is not bundled and
   is initially shared only by the eight listed sandbox accounts. Reusing an
   existing setup password does not reset it. On Linux or macOS, the equivalent
   is `node Run-Harborline.mjs` from the extracted folder.
3. Keep the terminal open. On the **same computer** visit
   <http://127.0.0.1:4279/> for ERP or <http://127.0.0.1:4280/> for employee
   self-service. Do not forward these ports or expose either portal.
4. Sign in with a listed demo account and read the Terms. Every account must
   decide whether to accept before records are returned. Declining leaves
   records locked. No acceptance is preloaded.
5. Stop the server with Ctrl+C. To reset, re-extract to a different folder,
   never overwrite other books. The standard Full Suite ZIP is separate.
   Computers may take several seconds to open the large demo's books.

| Portal | Username | Suggested starting point |
| --- | --- | --- |
| ERP | demo-owner | Companies, Projects, Sales, Accounting or Banking |
| ERP | demo-hr | Employee records and workforce history |
| ERP | demo-payroll | Existing approved historical employee pay records |
| Employee | demo-corporate | Parent staff profile and time |
| Employee | demo-freight | Freight project work and time |
| Employee | demo-parcel | Parcel timesheets or historical pay |
| Employee | demo-coach | Shuttle time and branding |
| Employee | demo-fleet | Fleet maintenance time and sample records |

## Explore 96 months of reports
- As demo-owner, switch among all five company books. Open **Project tracker**
  to inspect the original routes and work programs with new staffing; open
  **Jobs & time** for source work entries. Additional employee profiles have
  effective hire/separation dates, native project staffing and timesheets;
  not every profile is a demo login. Supplemental time illustrates job
  costing, not additional pay. Existing historical payroll records are
  preserved; the extension does not generate taxes or extra payroll postings.
- Use `REPORTS/OPERATIONS-INDEX.jsonl` to locate an operation ID and company,
  then open its numbered records in Sales, Purchasing, or Accounting. The
  extension links per-operation quote, order, fulfillment, invoice, receipt,
  vendor order/receiving/bill/payment, time, and approval.
- `ROUTE-COVERAGE.csv` shows each of 12 operating routes/programs for all 96
  months, plus the three parent-company projects. Parent projects have monthly
  staffing and ledger coverage throughout; the original operations index
  contains parent activity lines only from the extension. `MONTHLY-CONTROLS.csv`
  reconciles all 480 company-months. Both November 2026 bank cutoff records
  remain in the ERP; monthly summaries use the month-end one.
- `TIMESHEETS.csv`, `GENERAL-JOURNAL.csv`, `PROJECT-STAFFING-BY-MONTH.csv` and
  `ADDITIONAL-EMPLOYEES.csv` provide independent cross-reference. These are
  inspection exports, not files to import back into the demo.
- See `VERIFIED-COVERAGE.json` for counts and the fictional database digest.
  `SHA256SUMS.txt` verifies the untouched extracted files. The demo database
  will change locally after first-use setup, as intended.

This demo contains the unchanged public host from FirmQuill/FQ-Full-Suite
commit 1d41dc49b55278a49a093ce91cf61d21acb3fddb. No paid AI, credentials,
live institution connections, real tenant data or activation files are
included.
