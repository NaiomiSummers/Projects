@echo off
setlocal
cd /d "%~dp0"
where node.exe >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 24 and add it to PATH first.
  pause
  exit /b 1
)
node "%~dp0Create Harborline Import Files.mjs"
set "result=%errorlevel%"
pause
exit /b %result%
