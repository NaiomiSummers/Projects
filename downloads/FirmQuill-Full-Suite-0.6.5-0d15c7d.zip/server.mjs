import {modules as businessModules} from './shared/core.mjs';
import {fileURLToPath} from 'node:url';
import {workflowOnSidebar} from './web/main/navigation-groups.mjs';
import {recoveryCapacity} from './recovery.mjs';
import {initializeTimeKiosk,createTimeKiosk} from './time-kiosk.mjs';
import {createPasskeys,initializePasskeys,passkeyOrigin} from './passkeys.mjs';
import {createModuleActivation} from './module-activation.mjs';
import {createAddonListeners} from './addon-listener.mjs';
import {createAddonInstaller} from './addon-installer.mjs';
import {isOwnerRoute,isExternalRoute,forwardAddonRequest} from './addon-endpoints.mjs';
import {createAddonWorkspaceBridge} from './addon-workspace-broker.mjs';
import {createAddonDelegation} from './addon-delegation.mjs';
import {loadSignedSupportPackage} from './signed-support-package.mjs';
import {loadManualPackageFolder} from './manual-package-folder.mjs';
import {applyPayrollTemplates,previewPayrollTemplates,validatePayrollTemplatePayload,payrollTemplateId} from './payroll-template-package.mjs';
import {csvReceiptList,previewCsvUndo,executeCsvUndo} from './csv-recovery.mjs';
import {supportDiagnostics} from './support-diagnostics.mjs';
import {createScheduledBackups} from './scheduled-backups.mjs';
import {companyKnowledgeView,companyKnowledgeCommand} from './company-knowledge.mjs';
import {createPrivateFtps} from './ftps.mjs';
import {initializeCollaborationGroups,groupAdminView,groupAdminCommand} from './collaboration-groups.mjs';
import {initializeMessaging,messagingView,messagingCommand,latestMessageId} from './messaging.mjs';
import {initializeReportPackets,reportPackets} from './report-packet-store.mjs';
import {initializeMonthEndClose,canSeeMonthEnd,monthEndView,monthEndCommand,monthEndPacket} from './month-end-close.mjs';
import {catchUpPlanning,localPlanningDay,planningCommand,planningOf,planningSummary} from './shared/planning-core.mjs';
import {initializeManualPayroll,manualPayrollView,manualPayrollStoreCommand,manualPayrollPortableState} from './manual-payroll-store.mjs';
import {portableDeskState,portableDeskReport} from './portable-desk.mjs';
import {ownerDeskMigrationReports} from './desk-migration.mjs';
import {departmentView,departmentCommand} from './departments.mjs';
import {projectView,projectCommand,visibleProjectJobs,projectBusinessState} from './project-workspace.mjs';
import {assetsView,assetsCommand} from './assets-workspace.mjs';
import {createDriveService,createDriveRoutes} from './file-drives.mjs';
import {createPasswordWorkGate} from './password-work.mjs';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {randomBytes,createHash} from 'node:crypto';
import {termsVersion,termsText} from './web/legal/terms.mjs';
import {legacyAgreement} from './web/legal/consent.mjs';
import {openStore,tx,readBooks,saveBooks,revisionCheck,audit,safeUser,owner,scoped,passwordHash,passwordMatches,putUser,actionFor,approvalList,decide,auditEvents,requireThat,workerView,workerCommand} from './store.mjs';
import {inspectLite,exportLite,assertEmptyDestination} from './transfer.mjs';
import {recordsView,recordsCommand,recordFile,employeeProfile} from './records.mjs';
import {benefitsView,benefitsCommand,benefitFile,effectivePayrollDeductions} from './benefits.mjs';
import {createIdentityService} from './identity.mjs';
import {brandingSettings,saveWorkerBranding,workerBranding,workerBrandLogo} from './branding.mjs';
import {accountAreas,requireArea,ERP_AREAS,saveAreas,WORKER_FEATURES,workerFeatures,requireWorkerFeature,workerRecords} from './access.mjs';
import {migrationView,migrationCommand} from './migration.mjs';
import {createSupportService} from './support.mjs';
import {createContextualHelp,featuredHelpPages,workspaceHelpPages,mainHelpPages,workerHelpPages} from './contextual-help.mjs';
import {createSetupPackage} from './setup-package.mjs';
import {initializeTeamWorkflows,teamPages,purchasingView,purchasingCommand,myLeave,workerLeaveCommand,reviewLeave,reviewLeaveCommand} from './team-workflows.mjs';

const token=()=>randomBytes(32).toString('base64url');
const termsHash=createHash('sha256').update(termsText.replace(/\r\n?/g,'\n')).digest('hex');
const mime={html:'text/html; charset=utf-8',mjs:'text/javascript; charset=utf-8',css:'text/css; charset=utf-8',svg:'image/svg+xml',png:'image/png'};
const common=new Set(['passkeys-ui.mjs','passkey-browser.mjs','report-packet.mjs','report-packet-ui.mjs','app.css','mark.svg','headquarters.png','core.mjs','views.mjs','interop.mjs','payroll-rules.mjs','manual-payroll.mjs','manual-payroll-ui.mjs','file-drive-ui.mjs','knowledge-content.mjs','messaging-ui.mjs','planning-core.mjs','planning-views.mjs','warehouse-desk.mjs','contextual-help-ui.mjs','contextual-help.css']);
const mainFiles=new Set(['navigation-groups.mjs','index.html','app.mjs','suite.css','administration.mjs','record-admin.mjs','benefit-admin.mjs','identity-admin.mjs','connected-admin.mjs','department-workspace.mjs','assets-workspace.mjs','team-workflows.mjs','month-end-close.mjs','backup-admin.mjs','company-knowledge.mjs','private-ftps-ui.mjs','csv-recovery-ui.mjs','activation-ui.mjs','addon-ui.mjs','time-kiosk-ui.mjs','audit.html']);
const workerFiles=new Set(['index.html','app.mjs','worker.css','selfservice.mjs','kiosk.html','kiosk.mjs','kiosk.css']);
const deny=(n,msg)=>requireThat(false,n,msg);
const publicUser=u=>{const {authVersion,...fields}=u;return {...fields,version:authVersion};};
async function jsonBody(req,max){
  requireThat(['application/json','application/scim+json'].includes(req.headers['content-type']?.split(';')[0].trim().toLowerCase()),415,'Send JSON.');
  requireThat(!req.headers['content-length']||Number(req.headers['content-length'])<=max,413,'Request exceeds size limit.');
  const parts=[];let total=0;
  for await(const p of req){total+=p.length;requireThat(total<=max,413,'Request exceeds size limit.');parts.push(p);}
  let data;try{data=JSON.parse(Buffer.concat(parts).toString('utf8'));}catch{deny(400,'Invalid JSON.');}
  requireThat(data&&typeof data==='object'&&!Array.isArray(data),400,'Invalid request body.');
  return data;
}
function send(res,status,value){res.writeHead(status,{'Content-Type':res.getHeader('Content-Type')||'application/json; charset=utf-8'});res.end(JSON.stringify(value));}
async function createSuite({database,mainPort=4179,workerPort=4180,mainOrigin,workerOrigin,addonOrigin=mainOrigin,identityOptions={},supportOptions={},activationOptions={},addonOptions={},workspaceBridgeFactory=createAddonWorkspaceBridge,ftpsOptions={},ftpsTransport,driveFactory,backupOptions={},backupClock,backupIntervalMs=60_000,backupArchive,planningClock=localPlanningDay,planningIntervalMs=60_000}){
  if(addonOrigin)requireThat(new URL(addonOrigin).origin===addonOrigin&&new URL(addonOrigin).protocol==='https:'&&addonOrigin!==workerOrigin,400,'Configure an exact HTTPS origin for client endpoints, distinct from the worker portal.');
  const activation=await createModuleActivation(activationOptions);
  const db=openStore(database),sessions=new Map(),attempts=new Map();
  initializeTeamWorkflows(db);
  initializeMonthEndClose(db);
  initializeReportPackets(db);
  initializeCollaborationGroups(db);
  initializeMessaging(db);
  initializePasskeys(db);
  const passkeys=createPasskeys(db);
  initializeManualPayroll(db);
  const driveService=createDriveService(db), driveRoutes=createDriveRoutes(driveService);
  if(termsVersion===legacyAgreement.version&&termsHash===legacyAgreement.hash){
    db.prepare('INSERT OR IGNORE INTO terms_acceptance_hashes(account_id,version,content_hash,accepted_at) SELECT account_id,version,?,accepted_at FROM terms_acceptances WHERE version=?').run(termsHash,termsVersion);
  }
  const backups=createScheduledBackups({db,database,options:backupOptions,clock:backupClock,archive:backupArchive});
  const trust={entitlementVerifierPath:activationOptions.verifierPath,installationId:activation.status().installationId};
  const additionalTypes={[payrollTemplateId]:{type:payrollTemplateId,entitlement:payrollTemplateId,validate(files){
    const raw=files['templates.json'];
    requireThat(Object.keys(files).length===1&&typeof raw==='string'&&Buffer.byteLength(raw)<=64*1024,400,'Invalid payroll template package.');
    return validatePayrollTemplatePayload(JSON.parse(raw));
  }}};
  const scanOptions={...supportOptions.packageFolder,...trust,activationDirectory:activationOptions.directory,entitled:activation.allows,additionalTypes};
  let drop=await loadManualPackageFolder(scanOptions);
  if(!['unconfigured','verified','review-required'].includes(drop.status))process.emitWarning('FirmQuill did not load optional dropped content ('+drop.status+'). Check the signed package and license; normal app features remain available.');
  const legacy=drop.status==='unconfigured'?await loadSignedSupportPackage({...supportOptions.signedSupport,...trust}):null;
  if(legacy?.status==='invalid')process.emitWarning('FirmQuill did not admit the configured signed support package. Verify the package, release, installation ID and trusted public keys; normal app features remain available.');
  const workspaceBridge=workspaceBridgeFactory({db,sessions,getUrl:portal=> 'http://127.0.0.1:'+servers[portal==='worker'?1:0]?.address()?.port,mainOrigin,workerOrigin,hasAccepted,audit});
  const delegation=createAddonDelegation({db,hasAccepted,audit});
  const authorizeRuntime=approval=>{requireThat(approval&&typeof approval.id==='string',403,'The approving owner is unavailable.');const active=safeUser(db.prepare('SELECT * FROM accounts WHERE id=? AND active=1').get(approval.id));owner(active);requireThat(active.authVersion===approval.authVersion,403,'The approving owner must reauthorize this runtime.');requireThat(hasAccepted(active),428,'The approving owner must accept current Terms.');return active;};
  const addons=await createAddonInstaller({activationDirectory:activationOptions.directory,activation,workspaceBridge,delegation,authorizeRuntime,protectedPaths:[fileURLToPath(new URL('./',import.meta.url)),...(database===':memory:'?[]:[database])],...addonOptions});
  const listeners=createAddonListeners(db,addons,[mainOrigin,workerOrigin]);
  async function readAddonStatus(){
    const result=await addons.status();
    for(const installed of result.installed){
      if(addons.listenerService(installed.id))installed.listener=listeners.status(installed.id);
    }
    return result;
  }
  const publicSupport=createSupportService(),contextualHelp=createContextualHelp(supportOptions);
  const localOwnerSupport=()=>legacy?.status==='unconfigured'?createSupportService(supportOptions):createSupportService({signedSupportFiles:legacy?.files??drop.files??null});
  let ownerSupport=localOwnerSupport(),supportGeneration=0,applyingPackage=false;
  const packageAdmission=()=>({status:drop.status,capabilities:Object.entries(drop.packages??{}).map(([id,p])=>({id,version:p.version,active:activation.allows(p.entitlement)}))});
  async function shownActivation(){
    const eligibleModules=[];
    if(activation.allows('private-support')){
      const loaded=!!(drop.files||legacy?.files);
      const local=legacy?.status==='unconfigured'&&typeof supportOptions.documentationRoot==='string'&&await ownerSupport.info().then(()=>true,()=>false);
      if((loaded||local||await contextualHelp.hasContent())&&activation.allows('private-support'))eligibleModules.push('private-support');
    }
    if(drop.packages?.[payrollTemplateId]&&activation.allows(payrollTemplateId))eligibleModules.push(payrollTemplateId);
    const state=activation.status(),required=['private-support',payrollTemplateId].filter(m=>state.modules[m]);
    let upgrade={status:'partial',reason:'missing-license'};
    if(required.length){
      const review=drop.status==='unconfigured'?null:await loadManualPackageFolder({...scanOptions,operation:'preview'});
      const neededIds=required.map(m=>m==='private-support'?'full-suite-knowledge-base':m);
      const reviewStillCurrent=!review||neededIds.every(id=>review.candidates?.some(c=>c.id===id&&c.eligible&&c.reason==='already-applied'&&c.version===drop.packages?.[id]?.version));
      const complete=required.every(m=>eligibleModules.includes(m)&&activation.allows(m))&&reviewStillCurrent;
      const badDrop=review?.status==='invalid'||review?.candidates?.some(c=>neededIds.includes(c.id)&&c.reason==='revision-rejected');
      upgrade=complete?{status:'complete'}:{status:'partial',reason:badDrop?'package-error':'missing-packages'};
      if(!required.some(m=>activation.allows(m)))upgrade={status:'partial',reason:'missing-license'};
    }
    const addonStatus=await readAddonStatus();
    if(state.addons?.length){
      const installed=addonStatus.installed;
      if(installed.some(p=>p.pendingRestart))upgrade={status:'restart'};
      else if(state.addons.every(g=>installed.some(p=>p.id===g.id&&p.revision>=g.minRevision&&p.revision<=g.maxRevision&&['active','rolled-back'].includes(p.status)))&&(!required.length||upgrade.status==='complete'))upgrade={status:'complete'};
      else upgrade={status:'partial',reason:'package-error'};
    }
    return {...activation.status(),modules:Object.fromEntries(eligibleModules.filter(activation.allows).map(m=>[m,true])),eligibleModules:eligibleModules.filter(activation.allows),packageAdmission:packageAdmission(),addons:addonStatus,upgrade};
  }
  const privateFtps=createPrivateFtps({options:ftpsOptions,drive:driveFactory?driveFactory(db):driveService,transport:ftpsTransport,onSuccess:(user,company,detail)=>audit(db,user,company,'private-ftps',detail)});
  const identity=createIdentityService({db,database,readBooks,saveBooks,passwordHash,putUser,...identityOptions});
  const dummyHash=await passwordHash(token()),servers=[];
  const passwordWork=createPasswordWorkGate();
  initializeTimeKiosk(db);
  const kiosk=createTimeKiosk({db,accepted:hasAccepted,pinWork:passwordWork.immediate});
  let planningTimer,backupTimer;
  const refreshRecurring=()=>tx(db,()=>{const next=catchUpPlanning(readBooks(db).state,planningClock());if(next.generated)saveBooks(db,next.state);});
  const runRecurring=()=>{try{refreshRecurring();}catch{process.emitWarning('FirmQuill could not refresh recurring drafts. Review the workspace and retry.');}};
  const limited=passwordWork.immediate;
  const storeSession=(id,s)=>{for(const [k,v] of sessions)if(v.until<=Date.now()||v.absolute<=Date.now())sessions.delete(k);
    requireThat(sessions.size<10000,429,'Session capacity reached.');sessions.set(id,s);};
  function userFor(session,portal){
    requireThat(session?.portal===portal&&session.until>Date.now()&&session.absolute>Date.now(),401,'Sign in again.');
    session.checkDelegation?.();
    const u=safeUser(db.prepare('SELECT * FROM accounts WHERE id=? AND active=1').get(session.userId));
    requireThat(u&&u.authVersion===session.authVersion&&(u.role==='worker')===(portal==='worker'),401,'Sign in again.');
    if(session.passkeyId)requireThat(passkeys.currentCredential(u,portal,session.passkeyId),401,'Sign in again.');
    if(u.employeeId&&u.assignments.length===1)requireThat(!['inactive','disabled','deactivated','terminated'].includes(employeeProfile(db,readBooks(db).state,u.assignments[0],u.employeeId).employmentStatus),401,'Employee access is disabled.');
    if(u.role!=='worker'&&u.employeeId)requireThat(db.prepare('SELECT enabled FROM employee_erp_flags WHERE company=? AND employee=?').get(u.assignments[0],u.employeeId)?.enabled,401,'ERP access is disabled.');
    session.until=Date.now()+30*60000;return u;
  }
  function workspacePagesFor(user,state){
    if(user.role==='owner')return ['Departments','Project tracker','Assets & pallets','Inventory audit','Company knowledge','Messages','Collaboration groups','Month-end close',...teamPages(db,user)];
    const pages=[],departments=departmentView(db,user,state),projects=projectView(db,user,state);
    if(departments.workspaces.length)pages.push('Departments');
    if(projects.projects.length||departments.workspaces.some(w=>w.rights.includes('manage')))pages.push('Project tracker');
    const rights=new Set();for(const c of state.companies){try{for(const right of assetsView(db,user,state,{companyId:c.id}).rights)rights.add(right);}catch{}}if(['view','manage'].some(r=>rights.has(r)))pages.push('Assets & pallets');
    if(['audit','approve'].some(r=>rights.has(r)))pages.push('Inventory audit');
    return [...pages,...(canSeeMonthEnd(db,user,state)?['Month-end close']:[]),...(user.assignments.length&&accountAreas(db,user).includes('Company knowledge')?['Company knowledge']:[]),...teamPages(db,user),...(accountAreas(db,user).includes('Messages')&&state.companies.some(c=>user.assignments.includes(c.id))?['Messages']:[])];
  }
  function snapshot(user,s,extras={}){
    if(!hasAccepted(user))return {termsRequired:termsVersion,csrf:s.csrf};
    const {state,revision}=readBooks(db);
    const features=s.portal==='worker'?workerFeatures(db,user):[];
    const time=s.portal==='worker'?workerView(db,user,state):null;
    const renewal=s.portal==='main'&&user.role==='owner'?activation.renewalNotice():null;
    const help=contextualHelp.configured&&activation.allows('private-support')?{contextualHelpCandidate:true}:{};
    return s.portal==='worker'?{user:{id:user.id,name:user.name,role:'worker'},csrf:s.csrf,features,...help,...(features.includes('Drives')?{driveCompanyId:user.assignments[0]}:{}),branding:workerBranding(db,state,user.assignments[0]),data:features.includes('Time')?time:{company:time.company,employee:time.employee,timezone:time.timezone},records:workerRecords(db,user,(()=>{const r=recordsView(db,user,state),allowed=new Set(state.companies.flatMap(c=>visibleProjectJobs(db,user,c)).map(j=>j.id));if(r.jobs)r.jobs=r.jobs.filter(j=>allowed.has(j.id));return r;})()),benefits:features.includes('Benefits')?benefitsView(db,user,state):null,leave:features.includes('Time off')?myLeave(db,user,state):null}:
      {...(s.portal==='main'&&user.role==='owner'?{addonPages:addons.adminPages()}:{}),user:{...publicUser(user),areas:accountAreas(db,user),workspaces:workspacePagesFor(user,state)},csrf:s.csrf,state:scoped(user,state,db),revision,...help,...(renewal?{moduleRenewal:renewal}:{}),portalLinks:{main:mainOrigin||'http://127.0.0.1:'+servers[0]?.address()?.port,worker:workerOrigin||'http://127.0.0.1:'+servers[1]?.address()?.port},...extras};
  }
  function contextualScope(user,portal,page,companyId,state){
    if(!(portal==='worker'?workerHelpPages:mainHelpPages).has(page))return false;
    const selectedCompany=state.companies.find(c=>c.id===companyId);
    if(!companyId||!selectedCompany)return false;
    if(portal==='worker')return user.assignments[0]===companyId&&(['Home','Setup help'].includes(page)||workerFeatures(db,user).includes(page));
    if(!workflowOnSidebar(page,selectedCompany.featured,businessModules))return false;
    if(user.role==='owner')return true;
    if(!user.assignments.includes(companyId))return false;
    if(page==='Setup help')return true;
    if(workspaceHelpPages.has(page)){
      const company=state.companies.find(c=>c.id===companyId);
      return workspacePagesFor({...user,assignments:[companyId]}, {...state,companies:[company]}).includes(page);
    }
    if(!accountAreas(db,user).includes(page))return false;
    if(featuredHelpPages.has(page)||page==='Drives')return true;
    if(page==='Approvals')return ['manager','bookkeeper'].includes(user.role);
    if(page==='Audit trail')return user.role==='manager';
    if(page==='Employee records')return ['manager','hr','payroll'].includes(user.role);
    return page==='Benefits administration'&&['hr','payroll'].includes(user.role);
  }
  function hasAccepted(user){return !!db.prepare('SELECT 1 FROM terms_acceptance_hashes WHERE account_id=? AND version=? AND content_hash=?').get(user.id,termsVersion,termsHash);}
  function portalServer(portal,publicOrigin){
    return createServer(async(req,res)=>{
      const localPort=req.socket.localPort;
      const hostLabel=!publicOrigin&&req.headers.host==='localhost:'+localPort?'localhost':'127.0.0.1';
      const origin=publicOrigin||'http://'+hostLabel+':'+localPort;
      const secure=origin.startsWith('https://');
      const cookieName=(secure?'__Host-':'')+'fq_'+portal;
      const setCookie=(value,age)=>{const existing=res.getHeader('Set-Cookie'),cookies=existing?(Array.isArray(existing)?existing:[existing]):[];res.setHeader('Set-Cookie',[...cookies,cookieName+'='+value+'; HttpOnly; SameSite=Strict; Path=/; Max-Age='+age+(secure?'; Secure':'')]);};
      res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
      res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
      res.setHeader('X-Frame-Options','DENY');res.setHeader('Permissions-Policy','publickey-credentials-create=(self), publickey-credentials-get=(self)');
      try{
        const clientOrigin=addonOrigin||origin;
        const clientHost=portal==='main'&&req.headers.host===new URL(clientOrigin).host;
        const requestPath=req.url.split('?',1)[0];
        if(portal==='main'&&isExternalRoute(requestPath)){
          // A stock loopback installation may also host a domain selected by the
          // approving owner. Only the service's exact external paths use it.
          const dispatch=clientHost?addons.route(requestPath):!addonOrigin&&addons.route(requestPath,req.headers.host||'');
          requireThat(dispatch,404,'Endpoint unavailable.');
          await forwardAddonRequest(req,res,dispatch);return;
        }
        // A dedicated client hostname can only reach exact licensed external routes.
        if(clientHost&&addonOrigin&&addonOrigin!==publicOrigin)deny(404,'Endpoint unavailable.');
        requireThat(req.headers.host===new URL(origin).host||req.headers.host==='127.0.0.1:'+localPort,403,'Unknown host.');
        const url=new URL(req.url,origin),path=url.pathname;
        if(!path.startsWith('/api/')){
          requireThat(req.method==='GET'||req.method==='HEAD',405,'Method unavailable.');
          let name=path==='/'?'index.html':path==='/audit'&&portal==='main'?'audit.html':path==='/kiosk'&&portal==='worker'?'kiosk.html':path.slice(1),root='web/'+portal+'/';
          if(path.startsWith('/legal/')){
            name=path.slice(7);requireThat(['legal.html','legal.mjs','terms.mjs','consent.mjs','terms-ui.mjs','terms.css','account.mjs','privacy.html','privacy.css'].includes(name),404,'File unavailable.');root='web/legal/';
          }else if(path.startsWith('/shared/')){
            name=path.slice(8);requireThat(common.has(name)&&(portal==='main'||['passkeys-ui.mjs','passkey-browser.mjs','app.css','mark.svg','headquarters.png','file-drive-ui.mjs','knowledge-content.mjs','messaging-ui.mjs','contextual-help-ui.mjs','contextual-help.css'].includes(name)),404,'File unavailable.');root='shared/';
          }else requireThat((portal==='main'?mainFiles:workerFiles).has(name),404,'File unavailable.');
          const bytes=await readFile(new URL('./'+root+name,import.meta.url));res.writeHead(200,{'Content-Type':mime[name.split('.').pop()]});res.end(req.method==='HEAD'?undefined:bytes);return;
        }
        if(path.startsWith('/api/scim/')){
          requireThat(portal==='main',404,'Endpoint unavailable.');
          try{
            const body=['POST','PUT','PATCH'].includes(req.method)?await jsonBody(req,256*1024):undefined;
            const result=await identity.scim(req.method,url,req.headers,body);
            res.writeHead(result.status,result.headers);res.end(result.status===204?undefined:JSON.stringify(result.body));return;
          }catch(e){
            const status=e.status||400;res.writeHead(status,{'Content-Type':'application/scim+json; charset=utf-8'});res.end(JSON.stringify({schemas:['urn:ietf:params:scim:api:messages:2.0:Error'],status:String(status),detail:status===500?'Identity storage unavailable.':e.message}));return;
          }
        }
        const post=req.method==='POST';requireThat(post||req.method==='GET',405,'Method unavailable.');
        if(post)requireThat(req.headers.origin===origin,403,'Origin does not match this portal.');
        const cookies=(req.headers.cookie||'').split(';').map(x=>x.trim()),sid=cookies.find(x=>x.startsWith(cookieName+'='))?.slice(cookieName.length+1),s=sessions.get(sid);
        if(path.startsWith('/api/time-kiosk/')){
          requireThat(portal==='worker',404,'Endpoint unavailable.');
          const permittedHost=new URL(origin).host===req.headers.host;
          requireThat(permittedHost&&(secure||!publicOrigin),403,'Use the station’s configured HTTPS address or open it on the host.');
          const kioskCookie=(secure?'__Host-':'')+'fq_time_kiosk';
          const device=cookies.find(x=>x.startsWith(kioskCookie+'='))?.slice(kioskCookie.length+1);
          if(path==='/api/time-kiosk/status'&&!post){send(res,200,kiosk.status(device));return;}
          if(path==='/api/time-kiosk/pair'&&post){
            const p=await jsonBody(req,1024);requireThat(!res.destroyed,499,'Request ended.');
            requireThat(!kiosk.status(device).paired,409,'This browser already has a paired station.');
            const result=kiosk.pair(p,req.socket.remoteAddress);
            res.setHeader('Set-Cookie',kioskCookie+'='+result.value+'; HttpOnly; SameSite=Strict; Path=/; Max-Age='+result.maxAge+(secure?'; Secure':''));
            send(res,200,{paired:true,label:result.label});return;
          }
          if(path==='/api/time-kiosk/punch'&&post){
            const p=await jsonBody(req,1024);requireThat(!res.destroyed,499,'Request ended.');
            send(res,200,await kiosk.punch(device,p,dummyHash));return;
          }
          requireThat(false,404,'Endpoint unavailable.');
        }
        if(path==='/api/identity/providers'&&!post){send(res,200,{providers:identity.providers(portal)});return;}
        if(path==='/api/identity/invite/accept'&&post){
          const p=await jsonBody(req,4096);await limited(()=>identity.acceptInvite(p.token,p.password));send(res,200,{ok:true});return;
        }
        if(path==='/api/identity/oidc/start'&&!post){
          const result=await identity.beginOidc(url.searchParams.get('id'),origin+'/api/identity/oidc/callback',portal);
          res.setHeader('Set-Cookie','fq_oidc_binding='+result.binding+'; HttpOnly; SameSite=Lax; Path=/; Max-Age=600'+(secure?'; Secure':''));
          res.writeHead(302,{Location:result.redirect});res.end();return;
        }
        if(path==='/api/identity/oidc/callback'&&!post){
          const binding=cookies.find(x=>x.startsWith('fq_oidc_binding='))?.slice(16);
          res.setHeader('Set-Cookie','fq_oidc_binding=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'+(secure?'; Secure':''));
          const result=await identity.finishOidc(url.searchParams,origin+'/api/identity/oidc/callback',binding);
          const u=safeUser(db.prepare('SELECT * FROM accounts WHERE id=? AND active=1').get(result.userId));
          requireThat(u&&(u.role==='worker')===(portal==='worker'),401,'Identity is unavailable for this portal.');
          const fresh={userId:u.id,authVersion:u.authVersion,portal,csrf:token(),until:Date.now()+30*60000,absolute:Date.now()+12*3600000},key=token();
          userFor(fresh,portal);storeSession(key,fresh);setCookie(key,43200);res.writeHead(302,{Location:'/'});res.end();return;
        }
        const pkOrigin=path.startsWith('/api/passkeys/')?passkeyOrigin(portal,origin,req.headers.host):null;
        if(path==='/api/passkeys/available'&&!post){send(res,200,{available:!!pkOrigin});return;}
        if(post&&['/api/passkeys/sign-in/start','/api/passkeys/sign-in/finish'].includes(path)){
          requireThat(pkOrigin,403,'Passkeys are unavailable on this origin. Use your password.');
          const ip=req.socket.remoteAddress;
          passkeys.limit('login/'+portal+'/'+ip);
          const pkCookie=(secure?'__Host-':'')+'fq_pk_'+portal;
          const binding=cookies.find(x=>x.startsWith(pkCookie+'='))?.slice(pkCookie.length+1);
          const pkSet=(value,age)=>res.setHeader('Set-Cookie',pkCookie+'='+value+'; HttpOnly; SameSite=Strict; Path=/; Max-Age='+age+(secure?'; Secure':''));
          if(path.endsWith('/start')){
            await jsonBody(req,256);
            const {options,ticket}=await passkeys.loginStart(pkOrigin);pkSet(ticket,120);send(res,200,{options});return;
          }
          const p=await jsonBody(req,48*1024);pkSet('',0);
          const candidate=(u,k)=>{const time=Date.now();return {userId:u.id,authVersion:u.authVersion,portal,passkeyId:k,csrf:token(),until:time+30*60000,absolute:time+12*3600000};};
          const login=await passkeys.loginFinish(pkOrigin,binding,p.response,(row,k)=>userFor(candidate(row,k),portal));
          requireThat(!res.destroyed,401,'Sign in again.');
          const fresh=candidate(login.account,login.credential);userFor(fresh,portal);
          if(s?.portal===portal)sessions.delete(sid);
          const key=token();storeSession(key,fresh);setCookie(key,43200);send(res,200,snapshot(safeUser(login.account),fresh));return;
        }
        if(path==='/api/login'&&post){
          const p=await jsonBody(req,4096),username=String(p.username??'').trim().toLowerCase();
          const now=Date.now(),ip=req.socket.remoteAddress;
          for(const [k,b] of attempts)if(b.until<=now)attempts.delete(k);
          const keys=['user/'+username,'ip/'+ip];
          for(const [i,k] of keys.entries()){
            const b=attempts.get(k)||{count:0,until:now+300000};requireThat(b.count<(i?100:10),429,'Too many attempts. Try again in five minutes.');b.count++;attempts.set(k,b);
          }
          const row=db.prepare('SELECT * FROM accounts WHERE username=? AND active=1').get(username);
          const ended=new AbortController(),abort=()=>ended.abort();
          res.once('close',abort);
          let ok;
          try{
            if(res.destroyed)abort();
            ok=await passwordWork.login(ip,()=>passwordMatches(p.password,row?.hash||dummyHash),ended.signal);
          }finally{res.off('close',abort);}
          if(ended.signal.aborted||res.destroyed)return;
          const u=row&&safeUser(db.prepare('SELECT * FROM accounts WHERE id=? AND active=1').get(row.id));
          requireThat(ok&&u&&row.authVersion===u.authVersion&&(u.role==='worker')===(portal==='worker'),401,'Credentials are invalid for this portal.');
          const signedIn=Date.now();
          const fresh={userId:u.id,authVersion:u.authVersion,portal,csrf:token(),until:signedIn+30*60000,absolute:signedIn+12*3600000},key=token();
          userFor(fresh,portal);const data=snapshot(u,fresh);attempts.delete(keys[0]);if(s?.portal===portal)sessions.delete(sid);storeSession(key,fresh);setCookie(key,43200);send(res,200,data);return;
        }
        const u=userFor(s,portal);
        if(post)requireThat(req.headers['x-csrf-token']===s.csrf,403,'Reload before making changes.');
        if(path==='/api/session'&&!post){send(res,200,snapshot(u,s));return;}
        if(path==='/api/logout'&&post){sessions.delete(sid);setCookie('',0);send(res,200,{ok:true});return;}
        if(path==='/api/terms'&&post){
          const body=await jsonBody(req,512);requireThat(sessions.get(sid)===s,401,'Sign in again.');const account=userFor(s,portal);
          requireThat(body.version===termsVersion&&body.hash===termsHash,409,'Terms changed. Reload to read the current version.');
          tx(db,()=>{db.prepare('INSERT INTO terms_acceptance_hashes(account_id,version,content_hash,accepted_at) VALUES(?,?,?,?) ON CONFLICT(account_id,version,content_hash) DO NOTHING').run(account.id,termsVersion,termsHash,new Date().toISOString());});
          send(res,200,snapshot(account,s));return;
        }
        requireThat(hasAccepted(u),428,'Read and agree to the Terms of Service first.');
        if(path==='/api/time-kiosk-admin'){
          requireThat(portal==='main',404,'Endpoint unavailable.');owner(u);
          if(!post){send(res,200,kiosk.view(u,url.searchParams.get('companyId')));return;}
          const p=await jsonBody(req,2048);
          const live=()=>{requireThat(sessions.get(sid)===s&&!res.destroyed,401,'Sign in again.');const current=userFor(s,portal);requireThat(hasAccepted(current),428,'Read and agree to the Terms of Service first.');return current;};
          send(res,200,await kiosk.admin(p,live));return;
        }

        if(path.startsWith('/api/passkeys/')){
          requireThat(pkOrigin,403,'Passkeys are unavailable on this origin.');
          const live=()=>{requireThat(sessions.get(sid)===s,401,'Sign in again.');const active=userFor(s,portal);requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');return db.prepare('SELECT * FROM accounts WHERE id=?').get(active.id);};
          if(path==='/api/passkeys/list'&&!post){send(res,200,passkeys.list(pkOrigin,live()));return;}
          requireThat(post&&['/api/passkeys/register/start','/api/passkeys/register/finish','/api/passkeys/revoke'].includes(path),404,'Endpoint unavailable.');
          const p=await jsonBody(req,48*1024),row=live(),ip=req.socket.remoteAddress;
          let result;
          if(path.endsWith('/finish')){
            passkeys.limit('register-finish/'+row.id,30);
            result=await passkeys.finish(pkOrigin,row,sid,p.ticket,p.response,live);
          }else{
            requireThat(passkeys.list(pkOrigin,row).available,403,'Passkeys require a supported local account.');
            passkeys.limit('reauth/'+row.id,8);passkeys.limit('management/'+ip);
            const ended=new AbortController(),abort=()=>ended.abort();res.once('close',abort);
            let ok;try{if(res.destroyed)abort();ok=await passwordWork.login(ip,()=>passwordMatches(p.password,row.hash),ended.signal);}finally{res.off('close',abort);}
            if(ended.signal.aborted||res.destroyed)return;
            const active=live();requireThat(ok&&row.authVersion===active.authVersion,403,'Enter the current password for this account.');
            if(path.endsWith('/start')){
              result=await passkeys.begin(pkOrigin,active,sid,p.label);send(res,200,result);return;
            }
            result=passkeys.revoke(pkOrigin,active,p.id);
          }
          tx(db,()=>audit(db,u,'',path.endsWith('/revoke')?'passkey revoked':'passkey registered',portal+' portal'));
          send(res,200,result);return;
        }
        if(path==='/api/paid-upgrade-preview'){
          requireThat(portal==='main'&&post,404,'Endpoint unavailable.');
          owner(u);
          const input=await jsonBody(req,32*1024);
          const active=userFor(s,portal);
          requireThat(sessions.get(sid)===s,401,'Sign in again.');
          owner(active);
          requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');
          requireThat(input&&Object.keys(input).length===1&&Object.hasOwn(input,'code'),400,'Select an issuer-signed license file.');
          send(res,200,activation.preview(input.code));return;
        }
        if(path==='/api/addons'||path.startsWith('/api/addons/')){
          requireThat(portal==='main',404,'Endpoint unavailable.');owner(u);
          const current=()=>{requireThat(sessions.get(sid)===s&&!res.destroyed,401,'Sign in again.');const active=userFor(s,portal);owner(active);requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');return active;};
          current();
          if(path==='/api/addons/delegation'){
            const input=post?await jsonBody(req,8192):{id:url.searchParams.get('id')};
            requireThat(typeof input?.id==='string'&&/^[a-z][a-z0-9-]{2,63}$/.test(input.id),400,'Select an installed add-on.');
            const actor=current(),binding=addons.delegationBinding(input.id);
            requireThat(actor.id===binding.ownerId,403,'The approving owner is required.');
            send(res,200,post?delegation.configure(input,binding,actor):delegation.view(input.id,binding));return;
          }
          if(path==='/api/addons/listener'){
            requireThat(post,405,'Method unavailable.');
            const input=await jsonBody(req,1024);
            const value=await listeners.change(input,current);
            tx(db,()=>audit(db,current(),'','add-on listener '+input.action,JSON.stringify({id:input.id,host:value.host,port:value.port,origin:value.origin})));
            send(res,200,value);return;
          }
          if(path==='/api/addons/remove'){
            requireThat(post,405,'Method unavailable.');
            const input=await jsonBody(req,1024);
            requireThat(Object.keys(input).length===2&&typeof input.id==='string'&&input.confirm===true,400,'Confirm the package to remove.');
            const actor=current();
            const value=await addons.remove(input,current,id=>delegation.revoke(id));
            await listeners.remove(input.id);
            tx(db,()=>audit(db,actor,'','add-on removed',input.id));
            send(res,200,value);return;
          }
          if(path==='/api/addons/controls'){
            requireThat(post,405,'Method unavailable.');
            const input=await jsonBody(req,16384);
            const origin=addons.listenerService(input.id)?listeners.status(input.id).origin:clientOrigin;
            const result=await addons.controls(input,origin,current);
            const actor=current();
            if(input.action!=='view')tx(db,()=>audit(db,actor,'','add-on owner control',JSON.stringify({id:input.id,action:input.action})));
            send(res,200,result);return;
          }
          if(isOwnerRoute(path)){
            const dispatch=addons.route(path);requireThat(dispatch,404,'Endpoint unavailable.');
            const values=post?await jsonBody(req,16384):{};
            const result=await dispatch({channel:'owner-route',method:req.method,url:req.url,values,origin:clientOrigin},current);
            const actor=current();if(post)tx(db,()=>audit(db,actor,'','add-on owner control',path));
            send(res,200,result);return;
          }
          if(!post&&path==='/api/addons'){const value=await readAddonStatus();current();send(res,200,value);return;}
          if(!post&&path==='/api/addons/review'){const value=await addons.review();current();send(res,200,value);return;}
          const actions={'/api/addons/apply':['apply',['id','receipt','confirm']],'/api/addons/restart':['restart',['id','confirm']],'/api/addons/settings':['settings',['id','settings','confirm']],'/api/addons/invoke':['invoke',['id','value']],'/api/addons/write-policy':['writePolicy',['id','autoApproveWrites','confirm']],'/api/addons/approve-write':['approveWrite',['id','proposalId','digest','confirm']]};
          requireThat(post&&Object.hasOwn(actions,path),404,'Endpoint unavailable.');
          const [action,keys]=actions[path],input=await jsonBody(req,action==='invoke'?1024*1024:8192);
          requireThat(Object.keys(input).length===keys.length&&keys.every(k=>Object.hasOwn(input,k)),400,'Invalid add-on request.');
          if(action!=='invoke')tx(db,()=>audit(db,u,'','add-on owner request',JSON.stringify({id:input.id,action})));
          const value=await addons[action](input,current);current();if(action!=='invoke')tx(db,()=>audit(db,u,'','add-on owner approval',JSON.stringify({id:input.id,action})));send(res,200,value);return;
        }
        if(path==='/api/package-folder'){
          requireThat(portal==='main',404,'Endpoint unavailable.');owner(u);
          const authorize=()=>{requireThat(sessions.get(sid)===s&&!res.destroyed,401,'Sign in again.');const active=userFor(s,portal);owner(active);requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');};
          if(!post){
            const review=await loadManualPackageFolder({...scanOptions,operation:'preview'});
            authorize();
            send(res,200,{status:review.status,candidates:review.candidates??[],receipt:review.receipt??null});
            return;
          }
          const input=await jsonBody(req,1024);authorize();
          requireThat(input&&typeof input==='object'&&!Array.isArray(input)&&Object.keys(input).length===3&&input.confirm===true&&Array.isArray(input.ids)&&input.ids.length>=1&&input.ids.length<=8&&typeof input.receipt==='string'&&/^[0-9a-f]{64}$/.test(input.receipt),400,'Review the signed package folder and explicitly confirm before applying.');
          requireThat(!applyingPackage,409,'A package review is already being applied; refresh.');
          applyingPackage=true;
          try{
            const next=await loadManualPackageFolder({...scanOptions,operation:'apply',receipt:input.receipt,ids:input.ids,authorize});
            authorize();requireThat(next.status==='verified',409,'The reviewed package folder, entitlement, or verified revision changed. Open a fresh review.');
            const packages=Object.freeze({...drop.packages,...next.packages});
            drop={status:'verified',packages,files:packages['full-suite-knowledge-base']?.files};
            ownerSupport=localOwnerSupport();supportGeneration++;
            send(res,200,{packageAdmission:packageAdmission()});return;
          }finally{applyingPackage=false;}
        }
        if(path==='/api/module-activation/upload'){
          requireThat(portal==='main'&&post,404,'Endpoint unavailable.');owner(u);
          const input=await jsonBody(req,12000);
          requireThat(input&&typeof input==='object'&&!Array.isArray(input)&&Object.keys(input).length===2&&typeof input.code==='string'&&typeof input.fileName==='string'&&/^[^\\/\x00-\x1f]{1,120}\.fqlicense$/i.test(input.fileName),400,'Choose a signed .fqlicense file.');
          const current=()=>{requireThat(sessions.get(sid)===s&&!res.destroyed,401,'Sign in again.');const active=userFor(s,portal);owner(active);requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');};
          await activation.upload(input.code,current);
          await listeners.reconcile();
          tx(db,()=>audit(db,u,'','signed license activated','verified local upload'));
          const shown=await shownActivation();current();send(res,200,shown);return;
        }
        if(path==='/api/module-activation'){
          requireThat(portal==='main',404,'Endpoint unavailable.');
          owner(u);
          const current=()=>{requireThat(sessions.get(sid)===s,401,'Sign in again.');const active=userFor(s,portal);owner(active);requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');return active;};
          if(!post){const shown=await shownActivation();current();send(res,200,shown);return;}
          const input=await jsonBody(req,8192);
          const state=await activation.activate(input.code,current);
          tx(db,()=>audit(db,u,'','module entitlement activated',Object.keys(state.modules).filter(m=>state.modules[m]).join(', ')));
          const shown=await shownActivation();current();send(res,200,shown);return;
        }
        if(path==='/api/csv-import-recovery'){
          requireThat(portal==='main',404,'Endpoint unavailable.');
          owner(u);const companyId=url.searchParams.get('companyId')||'';
          const companyFrom=state=>{const c=state.companies.find(x=>x.id===companyId);requireThat(c,404,'Company not found.');return c;};
          if(!post){
            const company=companyFrom(readBooks(db).state),batch=url.searchParams.get('batch');
            send(res,200,batch?previewCsvUndo(db,company,batch):csvReceiptList(db,company));return;
          }
          const p=await jsonBody(req,2048);
          const result=tx(db,()=>{
            requireThat(sessions.get(sid)===s,401,'Sign in again.');const active=userFor(s,portal);owner(active);
            requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');
            const {state}=readBooks(db),company=companyFrom(state),out=executeCsvUndo(db,company,p,active);
            if(!out.repeated){
              company.bank=out.bank;saveBooks(db,state);
              audit(db,active,companyId,'CSV import recovery',p.batch+' · '+out.removed+' unmatched rows removed; no journal changed');
            }
            return {removed:out.removed,repeated:out.repeated};
          });
          send(res,200,result);return;
        }

        if(path==='/api/company-knowledge'){
          const companyId=url.searchParams.get('companyId')||undefined;
          if(post){
            requireThat(portal==='main',403,'Employee portal is read-only.');
            const input=await jsonBody(req,192*1024);
            const result=tx(db,()=>{
              const active=userFor(s,portal),value=companyKnowledgeCommand(db,active,readBooks(db).state,companyId,input);
              audit(db,active,companyId,'company knowledge '+value.operation,value.id+(value.version?' · version '+value.version:''));
              return value;
            });send(res,200,{result});return;
          }
          send(res,200,companyKnowledgeView(db,u,readBooks(db).state,{companyId,id:url.searchParams.get('id'),q:url.searchParams.get('q'),version:url.searchParams.get('version')}));return;
        }
        if(path==='/api/private-ftps'){
          requireThat(portal==='main',404,'Endpoint unavailable.');
          const current=()=>{requireThat(sessions.get(sid)===s,401,'Sign in again.');const user=userFor(s,portal);requireThat(hasAccepted(user),428,'Read and agree to the Terms of Service first.');return user;};
          if(post){const body=await jsonBody(req,4096);send(res,200,await privateFtps.command(current,body));}
          else send(res,200,privateFtps.status(u,{companyId:url.searchParams.get('companyId'),groupId:url.searchParams.get('groupId'),folderId:url.searchParams.get('folderId')}));
          return;
        }
        if(path.startsWith('/api/drives/')){
          await driveRoutes({req,res,url,user:u,readJson:max=>jsonBody(req,max),reauthorize:()=>{
            requireThat(sessions.get(sid)===s,401,'Sign in again.');
            const active=userFor(s,portal);requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');return active;
          }});return;
        }
        if(path==='/api/support/diagnostics'){
          requireThat(portal==='main'&&!post,404,'Endpoint unavailable.');
          owner(u);
          send(res,200,supportDiagnostics(db));return;
        }
        if(path==='/api/support/context'){
          requireThat(!post,404,'Endpoint unavailable.');
          const page=url.searchParams.get('page'),companyId=portal==='worker'?u.assignments[0]:url.searchParams.get('companyId');
          const allowed=user=>contextualScope(user,portal,page,companyId,readBooks(db).state);
          requireThat(activation.allows('private-support')&&allowed(u),404,'Endpoint unavailable.');
          const result=await contextualHelp.lookup({portal,page,companyId,role:u.role});
          requireThat(sessions.get(sid)===s,401,'Sign in again.');
          const active=userFor(s,portal);requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');
          const currentCompany=portal!=='worker'||active.assignments[0]===companyId;
          const validForMs=activation.remainingMs('private-support');
          requireThat(result.available&&validForMs>0&&currentCompany&&active.role===u.role&&allowed(active),404,'Endpoint unavailable.');
          send(res,200,url.searchParams.get('check')==='1'?{available:true,validForMs}:result);return;
        }
        if(path==='/api/managed-backups'){
          requireThat(portal==='main',404,'Endpoint unavailable.');
          owner(u);
          const current=()=>{requireThat(sessions.get(sid)===s,401,'Sign in again.');const active=userFor(s,portal);requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');return active;};
          const data=post?await backups.save(current(),await jsonBody(req,2048),current):await backups.view(current());
          owner(current());let capacity=null;
          try{capacity=recoveryCapacity(db);}catch{}
          send(res,200,{...data,capacity});return;
        }
        if((!post&&['/api/support/info','/api/support/search','/api/support/article'].includes(path))||(post&&path==='/api/support/answer')){
          const input=post?await jsonBody(req,4096):null;
          const privateAllowed=()=>{requireThat(sessions.get(sid)===s,401,'Sign in again.');const active=userFor(s,portal);requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');return url.searchParams.get('scope')!=='public'&&portal==='main'&&active.role==='owner'&&activation.allows('private-support');};
          const invoke=source=>path.endsWith('/info')?source.info():path.endsWith('/search')?source.search(url.searchParams.get('q')||''):path.endsWith('/article')?source.article(url.searchParams.get('id')):source.answer(input.question);
          const privateRequest=privateAllowed(),generation=supportGeneration;let answer;
          try{answer=await invoke(privateRequest?ownerSupport:publicSupport);}
          catch(e){if(!privateRequest||!path.endsWith('/info'))throw e;answer=await invoke(publicSupport);}
          send(res,200,privateRequest&&(!privateAllowed()||generation!==supportGeneration)?await invoke(publicSupport):answer);return;
        }
        if(path==='/api/report-packets'){
          requireThat(portal==='main',404,'Endpoint unavailable.');
          const input=post?await jsonBody(req,8192):undefined;
          requireThat(sessions.get(sid)===s,401,'Sign in again.');
          const active=userFor(s,portal);requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');
          send(res,200,reportPackets(db,active,url.searchParams.get('companyId'),input));return;
        }
        if(portal==='main'&&['/api/month-end-close','/api/month-end-close/packet'].includes(path)){
          const companyId=url.searchParams.get('companyId')||'',period=url.searchParams.get('period')||undefined;
          if(!post){
            send(res,200,path.endsWith('/packet')?monthEndPacket(db,u,{companyId,...readBooks(db)},period):monthEndView(db,u,{companyId,...readBooks(db)},period));return;
          }
          requireThat(path==='/api/month-end-close',405,'Method unavailable.');
          const p=await jsonBody(req,12*1024);
          requireThat(sessions.get(sid)===s,401,'Sign in again.');
          const out=tx(db,()=>{
            const active=userFor(s,portal);
            requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');
            return monthEndCommand(db,active,{companyId,...readBooks(db)},p.action);
          });
          send(res,200,out);return;
        }
        if(portal==='main'&&path==='/api/planning'){
          owner(u);
          if(post){
            const p=await jsonBody(req,64*1024);requireThat(p.action&&typeof p.action==='object',400,'Choose a planning action.');
            const count=tx(db,()=>{const active=userFor(s,portal);owner(active);const {revision,state}=readBooks(db);revisionCheck(revision,p.revision);
              const next=planningCommand(state,p.companyId,p.action,planningClock());saveBooks(db,next.state);
              audit(db,active,p.companyId,'planning '+p.action.type,'Company planning workflow');return next.generated;});
            send(res,200,snapshot(userFor(s,portal),s,{generatedDrafts:count}));return;
          }
          const {state}=readBooks(db),companyId=url.searchParams.get('companyId');
          const c=state.companies.find(c=>c.id===companyId);requireThat(c,404,'Company unavailable.');
          const rows=departmentView(db,u,state,{companyId}).workspaces.flatMap(w=>(w.records||[]).filter(x=>x.kind==='contract'));
          const today=planningClock(),extra=rows.map(r=>({id:r.sourceLiteId||r.id,name:r.title,date:(r.contractStatus||r.sourceStatus||(r.status==='done'?'Closed':'Active'))==='Active'?r.dueDate:''}));
          send(res,200,{day:today,data:planningOf(c),summary:planningSummary(c,today,extra)});return;
        }
        if(portal==='main'&&path==='/api/migration'){
          const result=post?migrationCommand(db,userFor(s,portal),await jsonBody(req,4*1024*1024)):migrationView(db,u);
          send(res,200,result.packageRequested?createSetupPackage(result.dataset,result.approval):result);return;
        }
        const {state:workforceState}=readBooks(db),scope={companyId:url.searchParams.get('companyId')||undefined,employeeId:url.searchParams.get('employeeId')||undefined};
        if(path==='/api/collaboration/messages'||portal==='main'&&path==='/api/collaboration/groups'){
          const messages=path.endsWith('/messages');
          const companyId=portal==='worker'?u.assignments[0]:scope.companyId;
          const params={companyId,state:workforceState};
          if(!post){
            send(res,200,messages?messagingView(db,u,params,{threadId:url.searchParams.get('threadId'),before:url.searchParams.get('before')}):groupAdminView(db,u,params));
            return;
          }
          const p=await jsonBody(req,48*1024);
          requireThat(sessions.get(sid)===s,401,'Sign in again.');
          const result=tx(db,()=>{
            const active=userFor(s,portal);
            requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');
            const fresh={companyId:portal==='worker'?active.assignments[0]:companyId,state:readBooks(db).state};
            return messages?messagingCommand(db,active,fresh,p.action):groupAdminCommand(db,active,fresh,p.action,{latestMessageId:latestMessageId(db)});
          });
          send(res,200,result);return;
        }
        if(portal==='main'&&['/api/team/purchasing','/api/team/time-off'].includes(path)){
          const purchasing=path.endsWith('/purchasing');
          if(!post){send(res,200,purchasing?purchasingView(db,u,workforceState,scoped(u,workforceState,db),scope.companyId):reviewLeave(db,u,workforceState,scope.companyId));return;}
          const p=await jsonBody(req,24*1024);requireThat(p.action&&typeof p.action==='object',400,'Specify a team request action.');
          const result=tx(db,()=>{const active=userFor(s,portal),{state}=readBooks(db);return purchasing?purchasingCommand(db,active,state,scoped(active,state,db),p.action):reviewLeaveCommand(db,active,state,p.action);});
          send(res,200,result);return;
        }
        if(portal==='worker'&&path==='/api/team/my-time-off'&&post){
          const p=await jsonBody(req,8192);requireThat(p.action&&typeof p.action==='object',400,'Specify a time-off action.');
          const active=userFor(s,portal);tx(db,()=>workerLeaveCommand(db,active,readBooks(db).state,p.action));
          send(res,200,snapshot(active,s));return;
        }
        if(portal==='worker'&&path==='/api/worker-brand/logo'&&!post){
          const logo=workerBrandLogo(db,workforceState,u.assignments[0]);requireThat(logo,404,'Company logo unavailable.');res.writeHead(200,{'Content-Type':logo.mime});res.end(logo.bytes);return;
        }
        if(portal==='main'&&path==='/api/worker-brand'){
          owner(u);if(!post){send(res,200,brandingSettings(db,workforceState,scope.companyId));return;}
          const p=await jsonBody(req,720*1024);
          const result=tx(db,()=>{const active=userFor(s,portal);owner(active);const result=saveWorkerBranding(db,readBooks(db).state,p);audit(db,active,p.companyId,'worker portal branding updated',JSON.stringify({mode:result.mode,parent:result.parent,hasLogo:result.hasLogo}));return result;});
          send(res,200,result);return;
        }
        if(portal==='main'&&['/api/departments','/api/projects','/api/assets'].includes(path)){
          const kind=path.slice(5);
          if(!post){const view=kind==='departments'?departmentView(db,u,workforceState,scope):kind==='projects'?projectView(db,u,workforceState,scope):assetsView(db,u,workforceState,{...scope,auditOnly:url.searchParams.get('auditOnly')==='true'});if(kind==='departments'&&u.role==='owner'&&scope.companyId)view.ownerDeskConversions=ownerDeskMigrationReports(db,scope.companyId);send(res,200,view);return;}
          const payload=await jsonBody(req,512*1024);requireThat(payload.action&&typeof payload.action==='object',400,'Choose a workspace action.');
          const result=tx(db,()=>{const active=userFor(s,portal),{state}=readBooks(db);const result=kind==='departments'?departmentCommand(db,active,state,payload.action):kind==='projects'?projectCommand(db,active,state,payload.action):assetsCommand(db,active,state,payload.action);if(result.state)saveBooks(db,result.state);return result.result||result;});
          send(res,200,{result});return;
        }
        if(portal==='main'&&['/api/workspaces/search','/api/workspaces/export'].includes(path)&&!post){
          const departments=departmentView(db,u,workforceState,scope),projects=projectView(db,u,workforceState,scope);
          if(path.endsWith('/export')){audit(db,u,scope.companyId||'','authorized workspace export','Permission-scoped records');send(res,200,{format:'firmquill.authorized-workspaces.v1',version:'0.4.0-preview.1',departments:departments.workspaces,projects:projects.projects});return;}
          const q=String(url.searchParams.get('q')||'').trim().toLowerCase();requireThat(q.length<=160,400,'Search within 160 characters.');
          const rows=[...departments.workspaces.flatMap(w=>(w.records||[]).map(r=>({id:r.id,type:r.kind,title:r.title}))),...projects.projects.flatMap(p=>[{id:p.id,type:'project',title:p.name},...(p.tasks||[]).map(t=>({id:t.id,type:'task',title:t.title}))])];
          send(res,200,{results:rows.filter(r=>!q||r.title.toLowerCase().includes(q)).slice(0,250)});return;
        }
        if(path==='/api/records'&&!post){if(portal==='main')requireArea(db,u,'Employee records');const r=recordsView(db,u,workforceState,scope);if(r.jobs){const allowed=new Set(workforceState.companies.flatMap(c=>visibleProjectJobs(db,u,c)).map(j=>j.id));r.jobs=r.jobs.filter(j=>allowed.has(j.id));}send(res,200,portal==='worker'?workerRecords(db,u,r):r);return;}
        if(path==='/api/benefits'&&!post){if(portal==='main')requireArea(db,u,'Benefits administration');else requireWorkerFeature(db,u,'Benefits');send(res,200,benefitsView(db,u,workforceState,scope));return;}
        if(path.startsWith('/api/records/file/')&&!post){if(portal==='main')requireArea(db,u,'Employee records');else requireWorkerFeature(db,u,'Pay');const f=recordFile(db,u,workforceState,decodeURIComponent(path.slice(18)));res.writeHead(200,{'Content-Type':f.mime,'Content-Disposition':'attachment; filename="'+f.filename.replace(/[^a-zA-Z0-9._-]/g,'_')+'"'});res.end(f.bytes);return;}
        if(path.startsWith('/api/benefits/file/')&&!post){if(portal==='main')requireArea(db,u,'Benefits administration');else requireWorkerFeature(db,u,'Benefits');const f=benefitFile(db,u,workforceState,decodeURIComponent(path.slice(19)));res.writeHead(200,{'Content-Type':f.mime,'Content-Disposition':'attachment; filename="'+f.filename.replace(/[^a-zA-Z0-9._-]/g,'_')+'"'});res.end(f.bytes);return;}
        if(post&&['/api/records/action','/api/benefits/action'].includes(path)){
          const kind=path.includes('/records/')?'records':'benefits';if(portal==='main')requireArea(db,u,kind==='records'?'Employee records':'Benefits administration');
          const p=await jsonBody(req,15*1024*1024);
          if(portal==='worker')requireWorkerFeature(db,u,kind==='benefits'?'Benefits':p.action?.type==='review-acknowledge'?'Reviews':'My Profile');
          const result=tx(db,()=>{const active=userFor(s,portal),{state}=readBooks(db);return kind==='records'?recordsCommand(db,active,state,p.action):benefitsCommand(db,active,state,p.action);});
          send(res,200,{result,...(portal==='worker'?snapshot(userFor(s,portal),s):{})});return;
        }
        if(portal==='main'&&path==='/api/identity'&&!post){requireArea(db,u,'Identity connectors');send(res,200,identity.view(u,workforceState,scope));return;}
        if(portal==='main'&&path==='/api/identity/action'&&post){requireArea(db,u,'Identity connectors');const p=await jsonBody(req,2*1024*1024);const result=await identity.command(u,workforceState,p.action);send(res,200,{result});return;}
        if(portal==='main'&&path==='/api/payroll-rule-templates'){
          const options={db,companyId:scope.companyId,allows:activation.allows,packageFor:()=>drop.packages?.[payrollTemplateId]??null};
          if(!post){send(res,200,previewPayrollTemplates({...options,user:u,state:workforceState}));return;}
          const input=await jsonBody(req,8192);
          const active=()=>{requireThat(sessions.get(sid)===s,401,'Sign in again.');const user=userFor(s,portal);requireThat(hasAccepted(user),428,'Read and agree to the Terms of Service first.');return user;};
          send(res,200,applyPayrollTemplates({...options,input,active,readState:()=>readBooks(db).state}));return;
        }
        if(portal==='main'&&path==='/api/manual-payroll'){
          if(!post){send(res,200,{...manualPayrollView(db,u,workforceState,scope.companyId),canProcess:true});return;}
          const input=await jsonBody(req,64*1024);
          const result=tx(db,()=>{
            requireThat(sessions.get(sid)===s,401,'Sign in again.');const active=userFor(s,portal);requireThat(hasAccepted(active),428,'Read and agree to the Terms of Service first.');
            return {...manualPayrollStoreCommand(db,active,readBooks(db).state,scope.companyId,input),canProcess:true};
          });
          send(res,200,result);return;
        }
        if(portal==='main'&&path==='/api/payroll/deductions'&&!post){requireArea(db,u,'Payroll');send(res,200,{deductions:effectivePayrollDeductions(db,u,workforceState,scope.companyId,url.searchParams.get('payDate'))});return;}
        if(portal==='main'&&path==='/api/admin/employee-erp'&&post){
          owner(u);const p=await jsonBody(req,16384),c=workforceState.companies.find(c=>c.id===p.companyId);
          userFor(s,portal);
          requireThat(c?.employees.some(e=>e.id===p.employeeId)&&typeof p.enabled==='boolean'&&Array.isArray(p.areas)&&p.areas.every(a=>ERP_AREAS.includes(a)),400,'Choose an employee and permitted ERP areas.');
          tx(db,()=>{db.prepare('INSERT INTO employee_erp_flags VALUES(?,?,?,?) ON CONFLICT(company,employee) DO UPDATE SET enabled=excluded.enabled,areas=excluded.areas').run(p.companyId,p.employeeId,Number(p.enabled),JSON.stringify(p.areas));
            for(const row of db.prepare("SELECT * FROM accounts WHERE employeeId=? AND role NOT IN ('owner','worker')").all(p.employeeId))if(JSON.parse(row.assignments).includes(p.companyId))db.prepare('UPDATE accounts SET active=?,authVersion=authVersion+1 WHERE id=?').run(Number(p.enabled),row.id);
            audit(db,u,p.companyId,'ERP access flags',JSON.stringify({employeeId:p.employeeId,enabled:p.enabled,areas:p.areas}));});send(res,200,{ok:true});return;
        }
        if(portal==='main'&&path==='/api/admin/employee-features'&&post){
          owner(u);const p=await jsonBody(req,16384),c=workforceState.companies.find(c=>c.id===p.companyId);
          userFor(s,portal);
          requireThat(c?.employees.some(e=>e.id===p.employeeId)&&Array.isArray(p.features)&&new Set(p.features).size===p.features.length&&p.features.every(f=>WORKER_FEATURES.includes(f)),400,'Choose valid employee features.');
          requireThat(p.features.includes('Time')||!db.prepare('SELECT 1 FROM worker_shifts WHERE company=? AND employee=? AND ended IS NULL').get(p.companyId,p.employeeId),409,'Close the employee’s open shift before disabling Time.');
          tx(db,()=>{db.prepare('INSERT INTO employee_portal_flags VALUES(?,?,?) ON CONFLICT(company,employee) DO UPDATE SET features=excluded.features').run(p.companyId,p.employeeId,JSON.stringify(p.features));audit(db,u,p.companyId,'employee feature flags',JSON.stringify({employeeId:p.employeeId,features:p.features}));});send(res,200,{ok:true});return;
        }
        if(portal==='worker'){
          requireThat(post&&path==='/api/worker/action',403,'Worker portal access only.');
          requireWorkerFeature(db,u,'Time');const p=await jsonBody(req,16384);requireThat(sessions.get(sid)===s,401,'Sign in again.');const active=userFor(s,portal);
          tx(db,()=>{const {state}=readBooks(db);workerCommand(db,active,state,p.action);audit(db,active,active.assignments[0],'worker '+p.action.type,'Clock or correction event');});
          send(res,200,snapshot(active,s));return;
        }
        if(!post){
          if(path==='/api/admin/users'){owner(u);send(res,200,{workerFeatureOptions:WORKER_FEATURES,erpAreaOptions:ERP_AREAS,users:db.prepare('SELECT * FROM accounts ORDER BY name,username').all().map(r=>({...publicUser(safeUser(r)),areas:accountAreas(db,safeUser(r)),configured:!!r.hash&&!r.hash.startsWith('!pending-invite:')})),employeeErp:db.prepare('SELECT * FROM employee_erp_flags').all().map(r=>({...r,enabled:!!r.enabled,areas:JSON.parse(r.areas)})),employeeFeatures:db.prepare('SELECT * FROM employee_portal_flags').all().map(r=>({...r,features:JSON.parse(r.features)}))});return;}
          if(path==='/api/approvals'){requireArea(db,u,'Approvals');send(res,200,{approvals:approvalList(db,u)});return;}
          if(path==='/api/audit'){requireArea(db,u,'Audit trail');send(res,200,{events:auditEvents(db,u)});return;}
          deny(404,'Endpoint unavailable.');
        }
        const transfer=path.startsWith('/api/transfer/');
        if(transfer||path==='/api/admin/user')owner(u);
        const p=await jsonBody(req,transfer?48*1024*1024:3*1024*1024);
        const active=()=>{requireThat(sessions.get(sid)===s,401,'Sign in again.');return userFor(s,portal);};
        let extras={};
        if(path==='/api/action'){if(p.action&&!p.action.requestId)p.action.requestId=p.requestId;extras=tx(db,()=>actionFor(db,active(),p));}
        else if(path==='/api/approve'){requireArea(db,u,'Approvals');tx(db,()=>decide(db,active(),p));}
        else if(path==='/api/admin/user'){
          if(!['worker','owner'].includes(p.role)){
            requireThat(Array.isArray(p.areas),400,'Select the ERP areas for this login.');
            if(p.employeeId&&p.active!==false){const flag=db.prepare('SELECT * FROM employee_erp_flags WHERE company=? AND employee=?').get(p.assignments?.[0],p.employeeId);requireThat(flag?.enabled&&p.areas.every(a=>JSON.parse(flag.areas).includes(a)),403,'Enable this employee’s ERP access and areas first.');}
          }
          const hash=p.password?await limited(()=>passwordHash(p.password)):null;
          const id=tx(db,()=>putUser(db,active(),p,hash));
          for(const [key,v] of sessions)if(v.userId===id&&key!==sid)sessions.delete(key);
          if(id===s.userId)s.authVersion=db.prepare('SELECT authVersion FROM accounts WHERE id=?').get(id).authVersion;
        }else if(transfer){
          owner(active());
          if(path==='/api/transfer/export'){
            const {state}=readBooks(db);requireThat(state.companies.length,400,'Create or import books first.');
            const portable=manualPayrollPortableState(db,portableDeskState(db,state)),deskReport=portableDeskReport(portable);const result=await limited(()=>exportLite(portable,p.password));owner(active());tx(db,()=>audit(db,u,'','export','Encrypted owner snapshot'));send(res,200,{...result,deskReport});return;
          }
          requireThat(['/api/transfer/preview','/api/transfer/import'].includes(path),404,'Endpoint unavailable.');
          assertEmptyDestination(readBooks(db).state);
          const plan=await limited(()=>inspectLite(p.envelope,p.password));owner(active());
          if(path.endsWith('preview')){
            const {revision,state}=readBooks(db);assertEmptyDestination(state);s.preview={digest:plan.digest,revision};
            send(res,200,{digest:plan.digest,summary:plan.summary,revision});return;
          }
          const confirm=()=>{
            const {revision,state}=readBooks(db);assertEmptyDestination(state);revisionCheck(revision,p.revision);
            requireThat(s.preview?.revision===revision&&s.preview?.digest===plan.digest&&plan.digest===p.digest,409,'Preview this backup again.');
            const operator=active();owner(operator);requireThat(hasAccepted(operator),428,'Read and agree to the Terms of Service first.');return operator;
          };
          let preWrite;
          if(backups.enabled()){confirm();preWrite=await backups.preWrite('reviewed-lite-import');}
          tx(db,()=>{
            const operator=confirm();preWrite?.();
            saveBooks(db,plan.state);audit(db,operator,'','import','Encrypted Lite migration · '+plan.digest);
          });delete s.preview;
        }else deny(404,'Endpoint unavailable.');
        send(res,200,snapshot(active(),s,extras));
      }catch(e){
        const status=e.status||((e.code||'').startsWith('ERR_SQLITE')||e.code==='ENOENT'?500:400);
        if(!res.headersSent&&!res.destroyed){
          if(status===429&&Number.isInteger(e.retryAfter))res.setHeader('Retry-After',String(e.retryAfter));
          send(res,status,{error:status===500?'Storage or application file unavailable.':e.message||'Request failed.'});
        }
      }
    });
  }
  try{
    for(const [portal,port,origin] of [['main',mainPort,mainOrigin],['worker',workerPort,workerOrigin]]){
      if(origin)requireThat(new URL(origin).origin===origin&&new URL(origin).protocol==='https:',400,'Company portal origins require exact HTTPS origins.');
      const server=portalServer(portal,origin);server.requestTimeout=45000;server.headersTimeout=15000;
      await new Promise((yes,no)=>server.once('error',no).listen(port,'127.0.0.1',yes));servers.push(server);
    }
  }catch(e){for(const srv of servers)srv.close();await listeners.close();await addons.close();await backups.close();db.close();throw e;}
  await addons.restore();
  runRecurring();planningTimer=setInterval(runRecurring,planningIntervalMs);planningTimer.unref();
  backups.tick();backupTimer=setInterval(backups.tick,backupIntervalMs);backupTimer.unref();
  return {mainUrl:'http://127.0.0.1:'+servers[0].address().port,workerUrl:'http://127.0.0.1:'+servers[1].address().port,
    async close(){await listeners.close();passwordWork.close();clearInterval(planningTimer);clearInterval(backupTimer);await Promise.all(servers.map(srv=>new Promise(r=>{srv.close(r);srv.closeIdleConnections();})));sessions.clear();await addons.close();await backups.close();db.close();}};
}

export {createSuite};

