@echo off
setlocal
cd /d "%~dp0"
where node.exe > nul 2>&1
if errorlevel 1 (
  echo Install Node.js 24 and add node.exe to PATH, then run this launcher again.
  pause
  exit /b 1
)
node.exe "Run-Harborline.mjs"
if errorlevel 1 pause
